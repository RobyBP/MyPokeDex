package com.example.mypokedex.data.remote.response

data class Species(
    val name: String,
    val url: String
)