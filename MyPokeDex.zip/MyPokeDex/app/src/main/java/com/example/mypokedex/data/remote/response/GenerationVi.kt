package com.example.mypokedex.data.remote.response

data class GenerationVi(
    val omegaRubyAlphaSapphire: OmegarubyAlphasapphire,
    val xY: XY
)