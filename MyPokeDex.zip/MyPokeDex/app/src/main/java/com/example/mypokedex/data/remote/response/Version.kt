package com.example.mypokedex.data.remote.response

data class Version(
    val name: String,
    val url: String
)