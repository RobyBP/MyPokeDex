package com.example.mypokedex.data.remote.response

data class VersionDetail(
    val rarity: Int,
    val version: VersionX
)