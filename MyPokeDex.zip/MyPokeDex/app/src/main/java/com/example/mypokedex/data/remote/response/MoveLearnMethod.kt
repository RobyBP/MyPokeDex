package com.example.mypokedex.data.remote.response

data class MoveLearnMethod(
    val name: String,
    val url: String
)