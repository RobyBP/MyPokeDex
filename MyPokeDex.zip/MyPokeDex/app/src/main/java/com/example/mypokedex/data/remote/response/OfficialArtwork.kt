package com.example.mypokedex.data.remote.response

data class OfficialArtwork(
    val front_default: String
)