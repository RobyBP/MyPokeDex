package com.example.mypokedex.data.remote.response

data class Versions(
    val generationI: GenerationI,
    val generationII: GenerationIi,
    val generationIII: GenerationIii,
    val generationIV: GenerationIv,
    val generationV: GenerationV,
    val generationVI: GenerationVi,
    val generationVII: GenerationVii,
    val generationVIII: GenerationViii
)