package com.example.mypokedex.data.remote.response

data class GenerationI(
    val redBlue: RedBlue,
    val yellow: Yellow
)