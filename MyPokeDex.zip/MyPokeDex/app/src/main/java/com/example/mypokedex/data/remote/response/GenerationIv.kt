package com.example.mypokedex.data.remote.response

data class GenerationIv(
    val diamondPearl: DiamondPearl,
    val heartGoldSoulSilver: HeartgoldSoulsilver,
    val platinum: Platinum
)