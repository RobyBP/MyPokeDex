package com.example.mypokedex.data.remote.response

data class MoveX(
    val name: String,
    val url: String
)