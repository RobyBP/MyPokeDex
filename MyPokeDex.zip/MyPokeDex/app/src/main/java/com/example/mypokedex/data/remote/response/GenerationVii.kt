package com.example.mypokedex.data.remote.response

data class GenerationVii(
    val icons: Icons,
    val ultraAunUltraMoon: UltraSunUltraMoon
)