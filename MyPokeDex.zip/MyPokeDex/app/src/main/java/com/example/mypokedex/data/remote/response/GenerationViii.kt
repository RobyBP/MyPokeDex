package com.example.mypokedex.data.remote.response

data class GenerationViii(
    val icons: IconsX
)