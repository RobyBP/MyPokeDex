package com.example.mypokedex.data.remote.response

data class DreamWorld(
    val front_default: String,
    val front_female: Any
)