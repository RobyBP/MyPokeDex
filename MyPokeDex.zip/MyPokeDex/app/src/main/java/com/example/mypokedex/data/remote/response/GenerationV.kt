package com.example.mypokedex.data.remote.response

data class GenerationV(
    val blackWhite: BlackWhite
)