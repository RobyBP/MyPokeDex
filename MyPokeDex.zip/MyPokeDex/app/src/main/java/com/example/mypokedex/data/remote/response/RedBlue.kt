package com.example.mypokedex.data.remote.response

data class RedBlue(
    val back_default: String,
    val back_gray: String,
    val front_default: String,
    val front_gray: String
)