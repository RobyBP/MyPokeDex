package com.example.mypokedex.data.remote.response

data class TypeX(
    val name: String,
    val url: String
)