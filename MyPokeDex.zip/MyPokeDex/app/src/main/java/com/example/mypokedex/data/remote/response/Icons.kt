package com.example.mypokedex.data.remote.response

data class Icons(
    val front_default: String,
    val front_female: Any
)