package com.example.mypokedex.data.remote.response

data class VersionX(
    val name: String,
    val url: String
)