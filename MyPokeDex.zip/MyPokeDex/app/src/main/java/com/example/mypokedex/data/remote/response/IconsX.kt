package com.example.mypokedex.data.remote.response

data class IconsX(
    val front_default: String,
    val front_female: Any
)