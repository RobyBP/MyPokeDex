package com.example.mypokedex.data.remote.response

data class GenerationIii(
    val emerald: Emerald,
    val fireredLeafgreen: FireredLeafgreen,
    val rubySapphire: RubySapphire
)