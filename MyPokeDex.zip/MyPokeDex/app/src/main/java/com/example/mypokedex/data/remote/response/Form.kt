package com.example.mypokedex.data.remote.response

data class Form(
    val name: String,
    val url: String
)