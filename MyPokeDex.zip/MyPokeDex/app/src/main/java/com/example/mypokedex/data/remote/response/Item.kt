package com.example.mypokedex.data.remote.response

data class Item(
    val name: String,
    val url: String
)