package com.example.mypokedex.data.remote.response

data class Emerald(
    val front_default: String,
    val front_shiny: String
)