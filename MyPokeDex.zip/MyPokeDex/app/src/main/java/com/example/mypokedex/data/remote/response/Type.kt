package com.example.mypokedex.data.remote.response

data class Type(
    val slot: Int,
    val type: TypeX
)