package com.example.mypokedex.data.remote.response

data class Result(
    val name: String,
    val url: String
)