package com.example.mypokedex.data.remote.response

data class Other(
    val dream_world: DreamWorld,
    val officialArtwork: OfficialArtwork
)