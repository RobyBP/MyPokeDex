package com.example.mypokedex.data.remote.response

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)