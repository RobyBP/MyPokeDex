package com.example.mypokedex.data.remote.response

data class GameIndice(
    val game_index: Int,
    val version: Version
)