package com.example.mypokedex.data.remote.response

data class Stat(
    val base_stat: Int,
    val effort: Int,
    val stat: StatX
)