package com.example.mypokedex.util

object Constants {
    const val baseUrl = "https://pokeapi.co/api/v2/"
    const val PAGE_SIZE = 20
}